Paleta de cores

#045933
#0BD97C
#4effa4
#b8ffda
black

fonte: roboto
